package com.example.lab_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
